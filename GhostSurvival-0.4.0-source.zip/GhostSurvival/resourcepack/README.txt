GhostSurvival 4D Resource Pack — implementation status

This folder is still a specification placeholder, not a deployable Bedrock resource pack.
The boss stage does not add custom 4D geometry. The boss is currently an existing mob
with a custom name tag and configurable stats; escort soldiers use the configured vanilla
entity identifier (default: Zombie).

A real 4D crate pack requires a valid Bedrock manifest, geometry, textures, entity/attachable
definitions, custom item registrations compatible with the exact PowerNukkitX build, and
client testing on the intended Bedrock versions. Do not distribute this placeholder as a pack.
