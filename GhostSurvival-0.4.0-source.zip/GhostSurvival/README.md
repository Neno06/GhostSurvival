# GhostSurvival 0.3.0 — PowerNukkitX RPG development build

Language: English + Spanish (bilingual by default)  
Target runtime: PowerNukkitX 1.21.4 / Java 21  
Build: Maven (`mvn clean package`)

## Implemented in this build

- `/ghost status|level|lang` basic status and language setting (language change requires admin permission).
- Persistent player balances and `/gmoney` transfers/admin balance command.
- `/gjob list|choose|status` for five starter professions. Hunter gains job XP from levelled mob kills.
- `/gquest list|claim`: daily hunt reward requires the configured number of levelled mob kills; a claim resets the kill counter.
- `/gclan create|join|leave|info|top|war` basic clan records and war declarations. War victory scoring and protection are not implemented yet.
- `/gcrate list|open` with five tiers and persistent keys; opening currently awards tier-based currency only.
- Level labels on spawned mobs and configurable outgoing damage scaling per mob level.
- Rare boss promotion of an existing mob (configurable chance), boss name/level/health and damage scaling where the entity API supports health setters.
- Broadcast announcements with world and XYZ coordinates when a boss is promoted.
- Configurable escort soldiers created around a boss using PowerNukkitX entity creation.
- Boss kill reward: configurable coins and one Ghost crate key for a player killer.
- `/gboss status` and admin-only `/gboss spawn` to promote a nearby mob for testing.
- Player XP and level-ups from killing levelled mobs, with configurable currency reward.
- Autosave and a low-frequency entity-count warning. It announces when the threshold is reached but does not delete entities.

## Commands

- `/ghost status`
- `/gmoney [pay <player> <amount>|admin <player> <amount>]`
- `/gjob list|choose <job>|status`
- `/gquest list|claim`
- `/gclan create <name>|join <name>|leave|info|top|war <clan>`
- `/gcrate list|open <wooden|iron|golden|ancient|ghost>`
- `/gadmin event|boss|reload|givecrate <player> <tier>`
- `/gboss status|spawn` (spawn requires admin and a nearby mob)

## Persistence

The plugin writes `players.properties` and `clans.properties` into its plugin data directory. Back up these files before upgrades or manual edits.

## 4D resource pack status

`resourcepack/` is a specification placeholder, not a finished pack. Real 4D crates need a valid Bedrock `manifest.json`, geometry, textures, attachables/entity definitions and matching custom item registrations for the exact PowerNukkitX build. The current crate command does not yet spawn a 4D crate block or model.

## Build and verification

Run `mvn clean package` with Java 21. The intended output is `target/GhostSurvival-0.3.0.jar`.

**Verification status:** this source archive has not been compiled against PowerNukkitX in this environment because Maven is unavailable and the dependency repository could not be reached. Do not treat a JAR as tested until it builds and is exercised on a test server.

## Not yet implemented

- Guaranteed boss health scaling across every mob class needs runtime testing against the target API; the current implementation uses reflective setters and logs if unavailable.
- Advanced boss abilities, unique physical loot drops, multiple boss archetypes and custom gear.
- Real 4D crate models/resource pack and item registration.
- Terrain protection, automated clan-war scoring/cooldowns and clan victory rewards.
- Physical supply drops, acid rain and meteorites.
- Full player-to-player item trading and automatic multi-objective quest tracking.
- Adaptive lag cleanup (currently warning-only by design).


## 0.4.0 — RPG gear prototype

Added `/ggear list` and `/ggear give <item>`. Players can request the starter RPG equipment; operators can use `/ggear give <player> <item>`. The gear uses named vanilla items with lore and server-side combat traits to avoid pretending that custom Bedrock item identifiers exist. `Ghostblade` and `Stormpick` apply a configurable damage multiplier; `Soulblade` applies a damage multiplier and a small heal on hit. Warden armor pieces are currently cosmetic named vanilla armor: full set defense bonuses are not implemented yet.

**Compatibility status:** not compiled against the PowerNukkitX 1.21.4 API in this environment. Verify the `Item.get(int, int, int)`, inventory and health APIs against your exact server build before deployment. 4D crate models still require a separately built Bedrock resource pack.
