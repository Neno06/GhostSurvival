package com.ghostsurvival;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.Listener;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.entity.EntitySpawnEvent;
import cn.nukkit.event.entity.EntityDeathEvent;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.entity.Entity;
import cn.nukkit.level.Position;
import cn.nukkit.item.Item;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.TextFormat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * GhostSurvival development build for PowerNukkitX.
 * Implements persistent starter RPG systems, levelled mob labels/damage, and kill XP.
 * Custom registries and Bedrock 4D resource-pack assets are not faked.
 */
public final class GhostSurvival extends PluginBase implements Listener {
    private static final String PREFIX = TextFormat.DARK_PURPLE + "[GhostSurvival] " + TextFormat.RESET;
    private final Properties players = new Properties();
    private final Properties clans = new Properties();
    private final Random random = new Random();
    // Runtime-only level cache. Entity IDs are discarded on death/despawn/restart.
    private final Map<Long, Integer> mobLevels = new ConcurrentHashMap<>();
    private final Map<Long, String> bossEntities = new ConcurrentHashMap<>();
    private final Map<Long, Boolean> soldierEntities = new ConcurrentHashMap<>();
    private Path playerFile;
    private Path clanFile;
    private long lastEventMillis = 0L;
    private String language = "bilingual";

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        playerFile = getDataFolder().toPath().resolve("players.properties");
        clanFile = getDataFolder().toPath().resolve("clans.properties");
        loadProperties(playerFile, players);
        loadProperties(clanFile, clans);
        saveDefaultConfig();
        language = getConfig().getString("settings.language", "bilingual").toLowerCase(Locale.ROOT);
        getServer().getPluginManager().registerEvents(this, this);
        int saveSeconds = Math.max(30, getConfig().getInt("settings.autosave-seconds", 120));
        getServer().getScheduler().scheduleRepeatingTask(this, this::saveData, saveSeconds * 20);
        getServer().getScheduler().scheduleRepeatingTask(this, this::runLagGuard, 20 * 60);
        getServer().getScheduler().scheduleRepeatingTask(this, this::maybeWorldEvent,
                Math.max(60, getConfig().getInt("events.interval-seconds", 1800)) * 20);
        getServer().getScheduler().scheduleRepeatingTask(this, this::bossSpawnCheck,
                Math.max(30, getConfig().getInt("bosses.check-seconds", 300)) * 20);
        getLogger().info("GhostSurvival enabled. Boss prototype and RPG core loaded.");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        String name = sender instanceof Player p ? p.getName() : "CONSOLE";
        switch (cmd) {
            case "ghost" -> {
                if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                    msg(sender, "§eCommands: /ghost status, /gmoney, /gjob, /gquest, /gclan, /gcrate, /gboss");
                    return true;
                }
                if (args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("level")) {
                    msg(sender, "§aGhostSurvival §7| §f" + tr("Language: ", "Idioma: ") + language
                            + " §7| §f" + tr("Balance: ", "Saldo: ") + money(name)
                            + " §7| §f" + tr("Level: ", "Nivel: ") + getInt(name, "level", 1)
                            + " §7| §fXP: " + getInt(name, "xp", 0) + "/" + xpNeeded(getInt(name, "level", 1)));
                    return true;
                }
                if (args[0].equalsIgnoreCase("lang") && args.length > 1 && (args[1].equalsIgnoreCase("english") || args[1].equalsIgnoreCase("spanish") || args[1].equalsIgnoreCase("bilingual"))) {
                    if (!sender.hasPermission("ghostsurvival.admin")) { msg(sender, "§cAdmin only / Solo administradores."); return true; }
                    language = args[1].toLowerCase(Locale.ROOT);
                    getConfig().set("settings.language", language);
                    saveConfig();
                    msg(sender, "§aLanguage updated / Idioma actualizado: " + language);
                    return true;
                }
                msg(sender, "§eUse /ghost help"); return true;
            }
            case "gmoney" -> { handleMoney(sender, args, name); return true; }
            case "gjob" -> { handleJob(sender, args, name); return true; }
            case "gquest" -> { handleQuest(sender, args, name); return true; }
            case "gclan" -> { handleClan(sender, args, name); return true; }
            case "gcrate" -> { handleCrate(sender, args, name); return true; }
            case "gadmin" -> { handleAdmin(sender, args); return true; }
            case "gboss" -> { handleBoss(sender, args); return true; }
            case "ggear" -> { handleGear(sender, args); return true; }
            default -> { return false; }
        }
    }

    /** Starter equipment module: named vanilla items with server-side RPG combat traits. */
    private void handleGear(CommandSender sender, String[] args, String name) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            msg(sender, "§dRPG gear / Equipo RPG: §fghostblade, soulblade, stormpick, wardenhelm, wardenchest, wardenlegs, wardenboots");
            msg(sender, "§7Traits / Efectos: Soulfire adds damage; Vampiric heals on hit; Warden armor is a starter custom set.");
            msg(sender, "§e/ggear give <item> (self) | /ggear give <player> <item> (admin)");
            return;
        }
        if (!args[0].equalsIgnoreCase("give")) { msg(sender, "§e/ggear list|give <item>"); return; }
        Player target;
        String itemName;
        if (args.length == 2 && sender instanceof Player player) {
            target = player; itemName = args[1].toLowerCase(Locale.ROOT);
        } else if (args.length >= 3 && sender.hasPermission("ghostsurvival.admin")) {
            target = getServer().getPlayer(args[1]); itemName = args[2].toLowerCase(Locale.ROOT);
            if (target == null) { msg(sender, "§cPlayer not online / El jugador no está conectado."); return; }
        } else { msg(sender, "§e/ggear give <item> or /ggear give <player> <item> (admin)"); return; }
        Item item;
        String display;
        String[] lore;
        switch (itemName) {
            case "ghostblade" -> { item = Item.get(276, 0, 1); display = "§5Ghostblade"; lore = new String[]{"§7GhostSurvival RPG", "§dSoulfire I: bonus damage", "§8Custom trait / Efecto personalizado"}; }
            case "soulblade" -> { item = Item.get(276, 0, 1); display = "§dSoulblade"; lore = new String[]{"§7GhostSurvival RPG", "§cVampiric I: heal on hit", "§8Custom trait / Efecto personalizado"}; }
            case "stormpick" -> { item = Item.get(278, 0, 1); display = "§bStormpick"; lore = new String[]{"§7GhostSurvival RPG", "§eStorm I: bonus damage to mobs", "§8Custom trait / Efecto personalizado"}; }
            case "wardenhelm" -> { item = Item.get(310, 0, 1); display = "§3Warden Helmet"; lore = new String[]{"§7GhostSurvival RPG", "§3Warden Set: defensive equipment"}; }
            case "wardenchest" -> { item = Item.get(311, 0, 1); display = "§3Warden Chestplate"; lore = new String[]{"§7GhostSurvival RPG", "§3Warden Set: defensive equipment"}; }
            case "wardenlegs" -> { item = Item.get(312, 0, 1); display = "§3Warden Leggings"; lore = new String[]{"§7GhostSurvival RPG", "§3Warden Set: defensive equipment"}; }
            case "wardenboots" -> { item = Item.get(313, 0, 1); display = "§3Warden Boots"; lore = new String[]{"§7GhostSurvival RPG", "§3Warden Set: defensive equipment"}; }
            default -> { msg(sender, "§cUnknown item / Objeto desconocido. Use /ggear list."); return; }
        }
        item.setCustomName(display); item.setLore(lore);
        target.getInventory().addItem(item);
        msg(sender, "§aGear delivered / Equipo entregado: §f" + display + " §7→ " + target.getName());
        if (sender != target) msg(target, "§aYou received / Recibiste: §f" + display);
    }

    private void handleMoney(CommandSender sender, String[] args, String name) {
        if (args.length == 0) { msg(sender, "§6Balance / Saldo: §e" + money(name)); return; }
        if (args[0].equalsIgnoreCase("pay") && args.length >= 3 && sender instanceof Player) {
            Player from = (Player) sender;
            Player to = getServer().getPlayer(args[1]);
            double amount = parseAmount(args[2]);
            if (to == null || amount <= 0 || money(from.getName()) < amount) { msg(sender, "§cInvalid player or amount / Jugador o cantidad inválida."); return; }
            setMoney(from.getName(), money(from.getName()) - amount);
            setMoney(to.getName(), money(to.getName()) + amount);
            msg(from, "§aPaid / Pagaste §e" + amount + " §ato " + to.getName());
            msg(to, "§aReceived / Recibiste §e" + amount + " §afrom " + from.getName());
            return;
        }
        if (args[0].equalsIgnoreCase("admin") && args.length >= 3 && sender.hasPermission("ghostsurvival.admin")) {
            String target = args[1]; double amount = parseAmount(args[2]);
            if (amount < 0) { msg(sender, "§cAmount must be non-negative / La cantidad debe ser positiva."); return; }
            setMoney(target, amount); msg(sender, "§aBalance set / Saldo establecido."); return;
        }
        msg(sender, "§e/gmoney [pay <player> <amount>|admin <player> <amount>]");
    }

    private void handleJob(CommandSender sender, String[] args, String name) {
        if (!(sender instanceof Player)) { msg(sender, "§cPlayers only / Solo jugadores."); return; }
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            msg(sender, "§eJobs / Trabajos: miner, hunter, farmer, explorer, blacksmith");
        } else if (args[0].equalsIgnoreCase("choose") && args.length > 1) {
            String job = args[1].toLowerCase(Locale.ROOT);
            if (!List.of("miner", "hunter", "farmer", "explorer", "blacksmith").contains(job)) { msg(sender, "§cUnknown job / Trabajo desconocido."); return; }
            players.setProperty(key(name, "job"), job); players.setProperty(key(name, "jobxp"), "0");
            msg(sender, "§aJob selected / Trabajo elegido: §e" + job);
        } else if (args[0].equalsIgnoreCase("status")) {
            msg(sender, "§eJob / Trabajo: §a" + players.getProperty(key(name, "job"), "none") + " §7XP: " + getInt(name, "jobxp", 0));
        } else msg(sender, "§e/gjob list|choose <job>|status");
    }

    private void handleQuest(CommandSender sender, String[] args, String name) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            msg(sender, "§eDaily missions / Misiones diarias: §fFirst Steps (join the world), §fMerchant (earn 100 coins), §fAdventurer (reach level 5)");
            msg(sender, "§7Hunt objective / Objetivo de caza: " + getInt(name, "mobkills", 0) + "/"
                + getConfig().getInt("progression.daily-kill-quest-target", 5) + " mobs. Claim after completing it / Reclama al completarlo.");
        } else if (args[0].equalsIgnoreCase("claim")) {
            if (getInt(name, "questclaim", 0) == dayStamp()) { msg(sender, "§cAlready claimed today / Ya reclamaste hoy."); return; }
            if (getInt(name, "mobkills", 0) < getConfig().getInt("progression.daily-kill-quest-target", 5)) {
                msg(sender, "§cDaily hunt requires " + getConfig().getInt("progression.daily-kill-quest-target", 5)
                        + " mob kills / La cacería diaria requiere más monstruos derrotados."); return;
            }
            setMoney(name, money(name) + 100); players.setProperty(key(name, "questclaim"), String.valueOf(dayStamp()));
            players.setProperty(key(name, "mobkills"), "0");
            msg(sender, "§aDaily reward / Recompensa diaria: §e100 coins");
        } else msg(sender, "§e/gquest list|claim");
    }

    private void handleClan(CommandSender sender, String[] args, String name) {
        if (!(sender instanceof Player)) { msg(sender, "§cPlayers only / Solo jugadores."); return; }
        if (args.length == 0) { msg(sender, "§e/gclan create <name>|join <name>|leave|info|top|war <clan>"); return; }
        if (args[0].equalsIgnoreCase("create") && args.length > 1) {
            String clan = args[1].replaceAll("[^A-Za-z0-9_]", "");
            if (clan.length() < 3 || clans.containsKey("clan." + clan + ".leader")) { msg(sender, "§cInvalid or existing clan / Clan inválido o existente."); return; }
            clans.setProperty("clan." + clan + ".leader", name); clans.setProperty("clan." + clan + ".members", name);
            players.setProperty(key(name, "clan"), clan); saveData(); msg(sender, "§aClan created / Clan creado: §e" + clan); return;
        }
        if (args[0].equalsIgnoreCase("join") && args.length > 1) {
            String clan = args[1]; String members = clans.getProperty("clan." + clan + ".members");
            if (members == null) { msg(sender, "§cClan not found / Clan no encontrado."); return; }
            String updated = members.contains(name) ? members : members + "," + name;
            clans.setProperty("clan." + clan + ".members", updated); players.setProperty(key(name, "clan"), clan);
            msg(sender, "§aJoined clan / Te uniste al clan: §e" + clan); return;
        }
        if (args[0].equalsIgnoreCase("leave")) {
            String clan = players.getProperty(key(name, "clan"));
            if (clan == null) { msg(sender, "§cYou are clanless / No tienes clan."); return; }
            String members = clans.getProperty("clan." + clan + ".members", "");
            List<String> kept = new ArrayList<>(List.of(members.split(","))); kept.removeIf(s -> s.equalsIgnoreCase(name));
            clans.setProperty("clan." + clan + ".members", String.join(",", kept)); players.remove(key(name, "clan"));
            msg(sender, "§aYou left / Saliste del clan."); return;
        }
        if (args[0].equalsIgnoreCase("info")) { msg(sender, "§eClan / Clan: §a" + players.getProperty(key(name, "clan"), "none")); return; }
        if (args[0].equalsIgnoreCase("war") && args.length > 1) {
            String own = players.getProperty(key(name, "clan")); String enemy = args[1];
            if (own == null || own.equalsIgnoreCase(enemy) || !clans.containsKey("clan." + enemy + ".leader")) { msg(sender, "§cInvalid clan / Clan inválido."); return; }
            clans.setProperty("war." + own + "." + enemy + ".started", String.valueOf(System.currentTimeMillis()));
            msg(sender, "§6War declared / Guerra declarada against / contra §e" + enemy + "§6. Prototype: combat results are not auto-scored yet."); return;
        }
        if (args[0].equalsIgnoreCase("top")) {
            List<String> entries = new ArrayList<>();
            for (String k : clans.stringPropertyNames()) if (k.startsWith("clan.") && k.endsWith(".wins")) entries.add(k.substring(0, k.length()-5) + " = " + clans.getProperty(k));
            entries.sort(Comparator.reverseOrder()); msg(sender, "§6Clan battle top / Top de batallas: §f" + (entries.isEmpty() ? "No battles recorded / Sin batallas registradas" : String.join(" | ", entries.subList(0, Math.min(5, entries.size()))))); return;
        }
        msg(sender, "§e/gclan create|join|leave|info|top|war");
    }

    private void handleCrate(CommandSender sender, String[] args, String name) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            msg(sender, "§6Crates / Cajas: §fWooden, Iron, Golden, Ancient, Ghost");
            msg(sender, "§74D models require the matching Bedrock resource pack; see resourcepack/README.txt."); return;
        }
        if (args[0].equalsIgnoreCase("open") && args.length > 1) {
            String tier = args[1].toLowerCase(Locale.ROOT);
            if (!List.of("wooden", "iron", "golden", "ancient", "ghost").contains(tier)) { msg(sender, "§cUnknown crate / Caja desconocida."); return; }
            String key = key(name, "crate." + tier);
            int count = getInt(name, "crate." + tier, 0);
            if (count <= 0) { msg(sender, "§cNo keys for this crate / No tienes llaves para esta caja."); return; }
            players.setProperty(key, String.valueOf(count - 1));
            // Safe starter reward; production reward pools are specified in config.yml.
            int reward = switch (tier) { case "wooden" -> 100; case "iron" -> 300; case "golden" -> 750; case "ancient" -> 2000; default -> 5000; };
            setMoney(name, money(name) + reward);
            msg(sender, "§dCrate opened / Caja abierta: §e" + tier + " §7+" + reward + " coins"); return;
        }
        msg(sender, "§e/gcrate list|open <tier>");
    }

    private void handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("ghostsurvival.admin")) { msg(sender, "§cNo permission / Sin permiso."); return; }
        if (args.length == 0) { msg(sender, "§e/gadmin event|boss|reload|givecrate <player> <tier>"); return; }
        if (args[0].equalsIgnoreCase("reload")) { reloadConfig(); language = getConfig().getString("settings.language", "bilingual"); msg(sender, "§aConfig reloaded / Configuración recargada."); return; }
        if (args[0].equalsIgnoreCase("event")) { broadcast("§bSupply signal / Señal de suministro: an event has been announced / se ha anunciado un evento."); return; }
        if (args[0].equalsIgnoreCase("boss")) {
            if (sender instanceof Player player) {
                Entity boss = promoteToBoss(findNearbyMob(player), true);
                if (boss == null) msg(sender, "§cNo nearby mob found. Stand near a mob and retry / No hay mobs cercanos.");
                else msg(sender, "§aBoss promoted / Jefe creado: " + boss.getNameTag());
            } else msg(sender, "§eUse /gboss spawn <player> from console / Usa /gboss spawn <jugador> desde consola.");
            return;
        }
        if (args[0].equalsIgnoreCase("givecrate") && args.length >= 3) {
            String tier = args[2].toLowerCase(Locale.ROOT);
            if (!List.of("wooden", "iron", "golden", "ancient", "ghost").contains(tier)) { msg(sender, "§cUnknown crate / Caja desconocida."); return; }
            String k = key(args[1], "crate." + tier); players.setProperty(k, String.valueOf(getInt(args[1], "crate." + tier, 0) + 1));
            msg(sender, "§aCrate key added / Llave añadida: " + args[1] + " / " + tier); return;
        }
        msg(sender, "§e/gadmin event|boss|reload|givecrate <player> <tier>");
    }

    private void handleBoss(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            msg(sender, "§e/gboss status | /gboss spawn (admin, near you)"); return;
        }
        if (args[0].equalsIgnoreCase("status")) {
            msg(sender, "§dActive bosses / Jefes activos: §f" + bossEntities.size()); return;
        }
        if (args[0].equalsIgnoreCase("spawn")) {
            if (!sender.hasPermission("ghostsurvival.admin")) { msg(sender, "§cAdmin only / Solo administradores."); return; }
            if (!(sender instanceof Player player)) { msg(sender, "§cRun in-game near a mob / Ejecuta dentro del juego cerca de un mob."); return; }
            Entity boss = promoteToBoss(findNearbyMob(player), true);
            if (boss == null) msg(sender, "§cNo nearby mob found / No se encontró un mob cercano.");
            else msg(sender, "§aBoss spawned / Jefe activado: " + boss.getNameTag());
            return;
        }
        msg(sender, "§e/gboss status|spawn");
    }

    private Entity findNearbyMob(Player player) {
        Entity nearest = null; double best = 12 * 12;
        for (Entity entity : player.getLevel().getEntities()) {
            if (entity == player || entity instanceof Player || entity.isClosed() || !looksLikeMob(entity)
                    || bossEntities.containsKey(entity.getId())) continue;
            double dx = entity.x - player.x, dy = entity.y - player.y, dz = entity.z - player.z;
            double distance = dx*dx + dy*dy + dz*dz;
            if (distance < best) { best = distance; nearest = entity; }
        }
        return nearest;
    }

    private Entity promoteToBoss(Entity entity, boolean forced) {
        if (entity == null || entity instanceof Player || bossEntities.containsKey(entity.getId())) return null;
        String bossName = getConfig().getString("bosses.name", "The Ghost Reaper");
        bossEntities.put(entity.getId(), bossName);
        int level = Math.max(getConfig().getInt("bosses.level", 50), mobLevels.getOrDefault(entity.getId(), 1));
        mobLevels.put(entity.getId(), level);
        entity.setNameTag("§5☠ §d" + bossName + " §8[§cLv." + level + "§8]");
        entity.setNameTagVisible(true); entity.setNameTagAlwaysVisible(true);
        double healthMultiplier = Math.max(1.0, getConfig().getDouble("bosses.health-multiplier", 8.0));
        try {
            var method = entity.getClass().getMethod("getMaxHealth");
            Object maxHealth = method.invoke(entity);
            if (maxHealth instanceof Number n) {
                float boosted = (float) Math.min(2048, n.doubleValue() * healthMultiplier);
                try { entity.getClass().getMethod("setMaxHealth", float.class).invoke(entity, boosted); }
                catch (NoSuchMethodException ex) { entity.getClass().getMethod("setMaxHealth", int.class).invoke(entity, (int) boosted); }
                entity.getClass().getMethod("setHealth", float.class).invoke(entity, boosted);
            }
        } catch (ReflectiveOperationException ignored) {
            getLogger().warning("Could not scale boss health for entity type " + entity.getClass().getSimpleName() + "; name and damage scaling remain active.");
        }
        broadcast("§5☠ LEGENDARY BOSS / JEFE LEGENDARIO §d" + bossName + " §7at / en §e" + entity.getFloorX() + ", " + entity.getFloorY() + ", " + entity.getFloorZ() + " §7world / mundo: " + entity.getLevel().getName());
        spawnBossSoldiers(entity);
        if (forced) getLogger().info("Boss promoted by admin at " + entity.getFloorX() + "," + entity.getFloorY() + "," + entity.getFloorZ());
        return entity;
    }

    private void spawnBossSoldiers(Entity boss) {
        int count = Math.max(0, Math.min(12, getConfig().getInt("bosses.soldier-count", 4)));
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2 * i) / Math.max(1, count);
            Position pos = new Position(boss.x + Math.cos(angle) * 2.5, boss.y, boss.z + Math.sin(angle) * 2.5, boss.getLevel());
            Entity soldier = null;
            try { soldier = Entity.createEntity(getConfig().getString("bosses.soldier-entity", "Zombie"), pos); }
            catch (Throwable error) { getLogger().warning("Could not create boss soldier: " + error.getMessage()); }
            if (soldier == null) continue;
            soldier.setNameTag("§cGuard / Guardia §7• §d" + getConfig().getString("bosses.name", "The Ghost Reaper"));
            soldier.setNameTagVisible(true); soldier.setNameTagAlwaysVisible(true);
            soldierEntities.put(soldier.getId(), true);
            try { soldier.spawnToAll(); } catch (Throwable error) { soldierEntities.remove(soldier.getId()); }
        }
    }

    private void bossSpawnCheck() {
        if (!getConfig().getBoolean("bosses.enabled", true) || !bossEntities.isEmpty()) return;
        // Spawn checks are probabilistic and only run on the configured low-frequency timer.
        if (random.nextDouble() >= Math.max(0.0, Math.min(1.0, getConfig().getDouble("bosses.spawn-chance-per-check", 0.002)))) return;
        List<Player> online = new ArrayList<>(getServer().getOnlinePlayers().values());
        if (online.isEmpty()) return;
        Player target = online.get(random.nextInt(online.size()));
        Entity candidate = findNearbyMob(target);
        if (candidate != null) promoteToBoss(candidate, false);
    }

    /** Assigns a level once per naturally spawned mob and displays it above the entity. */
    @EventHandler
    public void onMobSpawn(EntitySpawnEvent event) {
        if (!getConfig().getBoolean("mobs.levels.enabled", true)) return;
        Entity entity = event.getEntity();
        if (entity instanceof Player || entity == null || !looksLikeMob(entity)) return;
        int min = Math.max(1, getConfig().getInt("mobs.levels.min", 1));
        int max = Math.max(min, getConfig().getInt("mobs.levels.max", 30));
        int level = min + random.nextInt(max - min + 1);
        mobLevels.put(entity.getId(), level);
        String base = entity.getNameTag();
        if (base == null || base.isBlank()) base = entity.getClass().getSimpleName().replace("Entity", "");
        entity.setNameTag("§8[§cLv." + level + "§8] §f" + base);
        entity.setNameTagVisible(true);
        entity.setNameTagAlwaysVisible(true);
        if (getConfig().getBoolean("bosses.enabled", true)
                && random.nextDouble() < Math.max(0.0, Math.min(1.0, getConfig().getDouble("bosses.spawn-chance-per-mob", 0.0005)))) {
            promoteToBoss(entity, false);
        }
    }

    /** Higher-level mobs deal more damage. The multiplier is configurable and no tick scan is used. */
    @EventHandler
    public void onMobDamage(EntityDamageByEntityEvent event) {
        Entity attacker = event.getDamager();
        if (attacker instanceof Player player) {
            Item held = player.getInventory().getItemInHand();
            String heldName = held == null ? "" : held.getCustomName();
            if (heldName != null && (heldName.contains("Ghostblade") || heldName.contains("Stormpick"))) {
                event.setDamage((float) (event.getDamage() * getConfig().getDouble("gear.soulfire-damage-multiplier", 1.35)));
            } else if (heldName != null && heldName.contains("Soulblade")) {
                event.setDamage((float) (event.getDamage() * getConfig().getDouble("gear.vampiric-damage-multiplier", 1.20)));
                try { player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + (float) getConfig().getDouble("gear.vampiric-heal", 1.0))); } catch (Throwable ignored) { }
            }
            return;
        }
        Integer level = mobLevels.get(attacker.getId());
        if (level == null || event.isCancelled()) return;
        double perLevel = Math.max(0, getConfig().getDouble("mobs.levels.damage-per-level", 0.06));
        double multiplier = 1.0 + Math.max(0, level - 1) * perLevel;
        if (bossEntities.containsKey(attacker.getId())) multiplier *= getConfig().getDouble("bosses.damage-multiplier", 2.5);
        if (soldierEntities.containsKey(attacker.getId())) multiplier *= getConfig().getDouble("bosses.soldier-damage-multiplier", 1.25);
        event.setDamage((float) (event.getDamage() * multiplier));
    }

    /** Award persistent RPG XP and hunter job XP when a player kills a levelled mob. */
    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();
        String bossType = bossEntities.remove(entity.getId());
        soldierEntities.remove(entity.getId());
        Integer level = mobLevels.remove(entity.getId());
        if (bossType != null) {
            if (entity.getLastDamageCause() instanceof EntityDamageByEntityEvent damage
                    && damage.getDamager() instanceof Player killer) {
                String playerName = killer.getName();
                double reward = getConfig().getDouble("bosses.reward-coins", 2500);
                setMoney(playerName, money(playerName) + reward);
                int keys = getInt(playerName, "crate.ghost", 0) + 1;
                players.setProperty(key(playerName, "crate.ghost"), String.valueOf(keys));
                players.setProperty(key(playerName, "bosskills"), String.valueOf(getInt(playerName, "bosskills", 0) + 1));
                broadcast("§d[GhostSurvival] §6" + killer.getName() + " defeated " + bossType + "! / ¡derrotó a " + bossType + "! §e+" + reward + " coins, 1 Ghost key");
                saveData();
            } else broadcast("§d[GhostSurvival] §6" + bossType + " has fallen / El jefe ha caído.");
        }
        if (level == null) return;
        if (entity.getLastDamageCause() instanceof EntityDamageByEntityEvent damage
                && damage.getDamager() instanceof Player killer) {
            String name = killer.getName();
            int rewardXp = Math.max(1, getConfig().getInt("progression.mob-xp-base", 8) + level * 2);
            addPlayerXp(killer, rewardXp);
            if ("hunter".equalsIgnoreCase(players.getProperty(key(name, "job"), ""))) {
                int jobXp = getInt(name, "jobxp", 0) + Math.max(1, level);
                players.setProperty(key(name, "jobxp"), String.valueOf(jobXp));
            }
            int kills = getInt(name, "mobkills", 0) + 1;
            players.setProperty(key(name, "mobkills"), String.valueOf(kills));
            if (kills == 1) msg(killer, "§aFirst hunt / Primera cacería: §e+" + rewardXp + " XP");
            else msg(killer, "§7Mob defeated / Monstruo derrotado: §e+" + rewardXp + " XP §7(§cLv." + level + "§7)");
        }
    }

    private boolean looksLikeMob(Entity entity) {
        String type = entity.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        return type.startsWith("entity") && !type.contains("item") && !type.contains("arrow")
                && !type.contains("projectile") && !type.contains("orb") && !type.contains("boat")
                && !type.contains("minecart") && !type.contains("fallingblock") && !type.contains("tnt")
                && !type.contains("armorstand") && !type.contains("painting") && !type.contains("fishinghook");
    }

    private int xpNeeded(int level) {
        return Math.max(1, getConfig().getInt("progression.xp-per-level", 100) * Math.max(1, level));
    }

    private void addPlayerXp(Player player, int amount) {
        String name = player.getName();
        int level = Math.max(1, getInt(name, "level", 1));
        int xp = getInt(name, "xp", 0) + amount;
        boolean leveled = false;
        while (xp >= xpNeeded(level) && level < getConfig().getInt("progression.max-player-level", 100)) {
            xp -= xpNeeded(level);
            level++;
            leveled = true;
            setMoney(name, money(name) + getConfig().getDouble("progression.level-up-coins", 50));
        }
        players.setProperty(key(name, "level"), String.valueOf(level));
        players.setProperty(key(name, "xp"), String.valueOf(xp));
        if (leveled) {
            msg(player, "§6LEVEL UP! / ¡SUBISTE DE NIVEL! §e" + level + " §7(+" + getConfig().getDouble("progression.level-up-coins", 50) + " coins)");
        }
    }

    private void maybeWorldEvent() {
        if (!getConfig().getBoolean("events.enabled", true)) return;
        double chance = getConfig().getDouble("events.supply-drop-chance", 0.55);
        if (random.nextDouble() < chance) {
            broadcast("§b[Event] Supply signal detected! / ¡Señal de suministro detectada! §7(announcement-only prototype)");
        }
    }

    private void runLagGuard() {
        if (!getConfig().getBoolean("settings.lag-guard.enabled", true)) return;
        // Avoid expensive per-tick scans: this guard only performs a low-frequency player/entity count.
        int entities = 0;
        try { for (var level : getServer().getLevels().values()) entities += level.getEntities().length; }
        catch (Throwable ignored) { return; }
        int threshold = getConfig().getInt("settings.lag-guard.entity-warning-threshold", 180);
        if (entities >= threshold) {
            String message = "§c[GhostSurvival] Lag guard active / ¡Protección anti-lag activada! §7Entities/Entidades: " + entities;
            if (getConfig().getBoolean("settings.lag-guard.announce", true)) broadcast(message);
            getLogger().warning("Lag guard threshold reached: " + entities + " entities. No entities were removed automatically.");
        }
    }

    private void msg(CommandSender sender, String message) { sender.sendMessage(PREFIX + message); }
    private void broadcast(String message) { getServer().broadcastMessage(PREFIX + message); }
    private String tr(String en, String es) { return switch (language) { case "english" -> en; case "spanish" -> es; default -> en + es; }; }
    private String key(String player, String field) { return "player." + player.toLowerCase(Locale.ROOT) + "." + field; }
    private int getInt(String player, String field, int fallback) { try { return Integer.parseInt(players.getProperty(key(player, field), String.valueOf(fallback))); } catch (Exception e) { return fallback; } }
    private double money(String player) { try { return Double.parseDouble(players.getProperty(key(player, "money"), String.valueOf(getConfig().getDouble("economy.starting-balance", 250)))); } catch (Exception e) { return 0; } }
    private void setMoney(String player, double value) { players.setProperty(key(player, "money"), String.format(Locale.ROOT, "%.2f", value)); }
    private double parseAmount(String input) { try { return Double.parseDouble(input); } catch (Exception e) { return -1; } }
    private int dayStamp() { return (int) TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis()); }

    private void loadProperties(Path path, Properties target) {
        if (!Files.exists(path)) return;
        try (InputStream in = Files.newInputStream(path)) { target.load(in); }
        catch (IOException e) { getLogger().error("Could not load " + path.getFileName(), e); }
    }
    private synchronized void saveData() {
        saveProperties(playerFile, players);
        saveProperties(clanFile, clans);
    }
    private void saveProperties(Path path, Properties source) {
        if (path == null) return;
        try (OutputStream out = Files.newOutputStream(path)) { source.store(out, "GhostSurvival persistent data; back up before editing"); }
        catch (IOException e) { getLogger().error("Could not save " + path.getFileName(), e); }
    }
}
